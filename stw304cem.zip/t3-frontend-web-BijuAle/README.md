# Your Project Title

Name: Your full name here

CollegeID: Your college ID

Batch: Jan19A/19B/19C/19D


# Frontend code architecture

Provide a brief description of your front end code architecture including folder structure, API consumption, etc.

